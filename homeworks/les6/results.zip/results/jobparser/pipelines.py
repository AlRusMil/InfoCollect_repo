# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from pymongo import MongoClient
import re


class JobparserPipeline:

    def __init__(self):
        client = MongoClient('localhost', 27017)
        self.mongo_base = client.vacancies_db

    def process_item(self, item, spider):
        collection = self.mongo_base[spider.name]

        result: dict = {}
        result['name'] = item['vacancy_name'] if spider.name == 'hhru' else ''.join(item['vacancy_name'])

        result['salary'] = self.__salary_parsing(item['vacancy_salary'])

        tmp_link = item['vacancy_link'].split('?')
        result['link'] =tmp_link[0]

        collection.insert_one(result)

        return item

    @staticmethod
    def __salary_parsing(salary: list) -> dict:
        """
        Метод производит обработку списка с информацией о з/п.
        :param salary: список с информацией о з/п
        :return: словарь, содержащий поля "min", "max", "valuta"
        """
        dict_result = {}

        if ("указан" in salary[0]) or ("договор" in salary[0]):
            dict_result['min'] = None
            dict_result['max'] = None
            dict_result['valuta'] = None
            return dict_result

        # убираем последний элемент ("на руки", "до вычета налогов"), если он есть
        salary_str = ''.join(salary[:-1]) if (('рук' in salary[-1]) or ('налог' in salary[-1])) else ''.join(salary)
        salary_str = salary_str.replace(' ', '')
        salary_str = salary_str.replace('\xa0', '')
        salary_str = salary_str.replace('.', '')

        salary_digits = re.findall(r'\d+', salary_str)
        # маска: sum-sum...valuta
        if len(salary_digits) == 2:
            dict_result['min'] = float(salary_digits[0])
            dict_result['max'] = float(salary_digits[1])
            dict_result['valuta'] = re.search(r'[a-zA-Zа-яА-ЯеЁ]+$', salary_str).group()
        # маска: sum...valuta
        elif re.search(r'([оО][тТ])|([дД][оО])', salary_str) is None:
            dict_result['min'] = float(salary_digits[0])
            dict_result['max'] = float(salary_digits[0])
            dict_result['valuta'] = re.search(r'[a-zA-Zа-яА-ЯеЁ]+$', salary_str).group()
        # маска: от...sum...valuta
        elif re.search(r'[оО][тТ]', salary_str) is not None:
            dict_result['min'] = float(salary_digits[0])
            dict_result['max'] = None
            dict_result['valuta'] = re.search(r'[a-zA-Zа-яА-ЯеЁ]+$', salary_str).group()
        # маска: до...sum...valuta
        elif re.search(r'[дД][оО]', salary_str) is not None:
            dict_result['min'] = None
            dict_result['max'] = float(salary_digits[0])
            dict_result['valuta'] = re.search(r'[a-zA-Zа-яА-ЯеЁ]+$', salary_str).group()
        else:
            dict_result['salaryerr'] = 'unknown'

        return dict_result
