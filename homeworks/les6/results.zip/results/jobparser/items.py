# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class JobparserItem(scrapy.Item):
    vacancy_name = scrapy.Field()
    vacancy_salary = scrapy.Field()
    vacancy_link = scrapy.Field()
    _id = scrapy.Field()
    pass
