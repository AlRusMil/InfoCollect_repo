import scrapy
from scrapy.http import HtmlResponse
from jobparser.items import JobparserItem


class SjruSpider(scrapy.Spider):
    name = 'sjru'
    allowed_domains = ['superjob.ru']
    start_urls = ['https://www.superjob.ru/vacancy/search/?keywords=python&noGeo=1']

    def parse(self, response: HtmlResponse):
        next_page_butt = response.xpath("//a[contains(@class, 'f-test-button-dalshe')]/@href").extract_first()
        vacancies_links = response.xpath("//a[contains(@class, '_6AfZ9')]/@href").extract()

        for link in vacancies_links:
            print()
            yield response.follow(link, callback=self.vacancy_parse)

        if next_page_butt:
            yield response.follow(next_page_butt, callback=self.parse)
        else:
            return

    def vacancy_parse(self, response: HtmlResponse):
        item_name = response.xpath("//h1//text()").extract()
        item_salary = response.xpath("//span[contains(@class, 'ZON4b')]//span[contains(@class, '_2Wp8I')]//text()").extract()
        item_link = response.url
        yield JobparserItem(vacancy_name=item_name, vacancy_salary=item_salary, vacancy_link=item_link)