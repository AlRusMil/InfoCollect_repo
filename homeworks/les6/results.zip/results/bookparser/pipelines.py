# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from pymongo import MongoClient


class BookparserPipeline:

    def __init__(self):
        client = MongoClient('localhost', 27017)
        self.mongo_base = client.books_db

    def process_item(self, item, spider):
        collection = self.mongo_base[spider.name]

        result: dict = {}
        result['link'] = item['link']

        if spider.name == 'labru':
            result['name'] = item['name']
            result['main_price'] = float(item['main_price']) if item['main_price'] is not None else float(item['price'])
            result['discount_price'] = None if item['discount_price'] is None else float(item['discount_price'])
        elif spider.name == 'bookru':
            name = item['name']
            name = name.replace('\n', '')
            name = name.replace('    ', '')
            result['name'] = name

            main_price = item['main_price']
            if main_price is not None:
                main_price = item['main_price']
                main_price = main_price.replace('р.', '')
                main_price = main_price.replace(' ', '')
                main_price = main_price.replace('\xa0', '')

            discount_price = item['discount_price']
            if discount_price is not None:
                discount_price = discount_price.replace(' ', '')

            result['main_price'] = float(main_price) if main_price is not None else float(discount_price)
            result['discount_price'] = None if main_price is None else float(discount_price)

        result['authors'] = None if len(item['authors']) == 0 else item['authors']
        result['rate'] = float(item['rate']) if item['rate'] is not None else None

        collection.insert_one(result)

        return item
