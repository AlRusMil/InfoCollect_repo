# 1) Создать двух пауков по сбору данных о книгах с сайтов labirint.ru и book24.ru
# 2) Каждый паук должен собирать:
# * Ссылку на книгу
# * Наименование книги
# * Автор(ы)
# * Основную цену
# * Цену со скидкой
# * Рейтинг книги
# 3) Собранная информация дожна складываться в базу данных

from scrapy.settings import Settings
from scrapy.crawler import CrawlerProcess

from bookparser import settings
from bookparser.spiders.labru import LabruSpider
from bookparser.spiders.bookru import BookruSpider

if __name__ == '__main__':
    crawler_settings = Settings()
    crawler_settings.setmodule(settings)

    process = CrawlerProcess(settings=crawler_settings)
    process.crawl(LabruSpider)
    process.crawl(BookruSpider)

    process.start()
