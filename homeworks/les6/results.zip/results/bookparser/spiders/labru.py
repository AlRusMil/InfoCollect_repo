import scrapy
from scrapy.http import HtmlResponse
from bookparser.items import BookparserItem


class LabruSpider(scrapy.Spider):
    name = 'labru'
    allowed_domains = ['labirint.ru']
    start_urls = ['https://www.labirint.ru/search/%D0%BF%D1%81%D0%B8%D1%85%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D1%8F/?stype=0']

    def parse(self, response: HtmlResponse):
        next_page_butt = response.xpath("//a[@title='Следующая']/@href").extract_first()
        books_links = response.xpath("//a[@class='product-title-link']/@href").extract()

        for link in books_links:
            yield response.follow(link, callback=self.book_parse)

        if next_page_butt:
            yield response.follow(next_page_butt, callback=self.parse)
        else:
            return

    def book_parse(self, response: HtmlResponse):
        item_link = response.url
        item_name = response.xpath("//h1/text()").extract_first()
        item_authors = response.xpath("//a[@data-event-label='author']/text()").extract()
        item_price = response.xpath("//span[@class='buying-price-val-number']/text()").extract_first()
        item_main_price = response.xpath("//span[@class='buying-priceold-val-number']/text()").extract_first()
        item_discount_price = response.xpath("//span[@class='buying-pricenew-val-number']/text()").extract_first()
        item_rate = response.xpath("//div[@id='rate']/text()").extract_first()
        yield BookparserItem(link=item_link, name=item_name, authors=item_authors, price=item_price,
                             main_price=item_main_price, discount_price=item_discount_price, rate=item_rate)
