import scrapy
from scrapy.http import HtmlResponse
from bookparser.items import BookparserItem


class BookruSpider(scrapy.Spider):
    name = 'bookru'
    allowed_domains = ['book24.ru']
    start_urls = ['https://book24.ru/search/'
                  '?q=%D0%BF%D1%81%D0%B8%D1%85%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D1%8F#catalog-products']

    def parse(self, response: HtmlResponse):
        next_page_butt = response.xpath("//a[contains(@class, '_text')]/@href").extract()
        books_links = response.xpath("//a[contains(@class, 'book-preview__title-link')]/@href").extract()

        for link in books_links:
            yield response.follow(link, callback=self.book_parse)

        if next_page_butt:
            yield response.follow(next_page_butt[-1], callback=self.parse)
        else:
            return

    def book_parse(self, response: HtmlResponse):
        item_link = response.url
        item_name = response.xpath("//h1/text()").extract_first()
        item_authors = response.xpath("//a[@itemprop='author']/text()").extract()
        # item_price = response.xpath("//span[@class='buying-price-val-number']/text()").extract_first()
        item_main_price = response.xpath("//div[@class='item-actions__price-old']/text()").extract_first()
        item_discount_price = response.xpath("//div[contains(@class, 'item-actions__price')]/b/text()").extract_first()
        item_rate = response.xpath("//div[contains(@class, 'rating__rate-value')]/text()").extract_first()
        yield BookparserItem(link=item_link, name=item_name, authors=item_authors,  # price=item_price,
                             main_price=item_main_price, discount_price=item_discount_price, rate=item_rate)