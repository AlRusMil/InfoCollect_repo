import scrapy
from scrapy.http import HtmlResponse
from instaparser.items import InstaparserItem

import re
import json
from urllib.parse import urlencode
from copy import deepcopy


class InstagramcomSpider(scrapy.Spider):
    name = 'instagramcom'
    allowed_domains = ['instagram.com']
    start_urls = ['https://instagram.com/']

    insta_login = 'UsStud01'
    insta_pwd = '#PWD_INSTAGRAM_BROWSER:10:1616368274:AVVQAEN6cfEOH32oCMPCVdlxTAfrIRiXKR7QntGDMQuZP5xU/t9mz6g+ew/' \
                '97wgS2U0QhfiQaGayo7c3gRWKV6VBaKNXbgS3XczmL4n9jguRZF3w9WIv3jBLV9wQCKqvkdnG6TL/ZbH++xNAlydRPyKw'
    inst_login_link = 'https://instagram.com/accounts/login/ajax/'

    parse_pages = ['soul_box_spb', 'choco_lul']

    graphql_url = 'https://www.instagram.com/graphql/query/?'
    # hash для получения данных о подписчиках и подписках
    data_hashes = {'Subscribers': '5aefa9893005572d237da5068082d8d5',
                   'Subscriptions': '3dec7e2c57367ef3da3d987d89f9dbc8'}

    i = 0

    def parse(self, response: HtmlResponse):                # Первый запрос на стартовую страницу.
                                                            # Результат работы - авторизация на своей странице.
        csrf_token = self.fetch_csrf_token(response.text)   # csrf-токен забираем из html
        yield scrapy.FormRequest(                           # Заполняем форму для авторизации
            self.inst_login_link,
            method='POST',
            callback=self.page_parse,
            formdata={'username': self.insta_login, 'enc_password': self.insta_pwd},
            headers={'X-CSRFToken': csrf_token}
        )

    # Получаем токен для авторизации
    def fetch_csrf_token(self, text):
        matched = re.search('\"csrf_token\":\"\\w+\"', text).group()
        return matched.split(':').pop().replace(r'"', '')

    def page_parse(self, response: HtmlResponse):   # Обход всех интересующих страниц.
                                                    # Результат - переход на интересующие страницы.
        j_body = json.loads(response.text)
        if j_body['authenticated']:             # Проверяем ответ после авторизации
            for page in self.parse_pages:       # Циклом проходимся по списку интересующих страниц
                yield response.follow(          # Переходим на интересующую страницу
                    f'/{page}',
                    callback=self.page_data_parse,
                    cb_kwargs={'pagename': page}
                )

    def page_data_parse(self, response: HtmlResponse, pagename):    # Работа на интересующей странице.
                                                                    # Результат - вызов функций для получения данных.
        page_id = self.fetch_page_id(response.text, pagename)       # Получаем id пользователя
        variables = {                                               # Формируем словарь для передачи данных в запрос
            'id': page_id,
            'first': 24
        }

        # Формируем ссылку для получения данных о подписчиках и вызываем соответствующий метод
        type_info = 'Subscribers'
        url_graphql_subscribers = f"{self.graphql_url}query_hash={self.data_hashes[type_info]}&{urlencode(variables)}"
        yield response.follow(
            url_graphql_subscribers,
            callback=self.page_subscribers_parse,
            cb_kwargs={
                'pagename': pagename,
                'page_id': page_id,
                'variables': deepcopy(variables),    # variables через deepcopy во избежание гонок
                'type_info': type_info
            }
        )

        # Формируем ссылку для получения данных о подписках и вызываем соответствующий метод
        type_info = 'Subscriptions'
        url_graphql_subscriptions = f"{self.graphql_url}query_hash={self.data_hashes[type_info]}&{urlencode(variables)}"
        yield response.follow(
            url_graphql_subscriptions,
            callback=self.page_subscriptions_parse,
            cb_kwargs={
                'pagename': pagename,
                'page_id': page_id,
                'variables': deepcopy(variables),    # variables через deepcopy во избежание гонок
                'type_info': type_info
            }
        )

    # Получаем id желаемого пользователя
    def fetch_page_id(self, text, username):
        matched = re.search(
            '{\"id\":\"\\d+\",\"username\":\"%s\"}' % username, text
        ).group()
        return json.loads(matched).get('id')

    # Принимаем ответ на запрос на получение подписчиков
    # Параметр type - для унификации методов
    def page_subscribers_parse(self, response: HtmlResponse, pagename, page_id, variables, type_info):
        j_data = json.loads(response.text)
        page_info = j_data.get('data').get('user').get('edge_followed_by').get('page_info')
        if page_info.get('has_next_page'):                  # Если есть следующая страница
            variables['first'] = 12                         # Новое значения количества получения новых данных
            variables['after'] = page_info['end_cursor']    # Новый параметр для получения следующих данных
            url_graphql_info = f"{self.graphql_url}query_hash={self.data_hashes[type_info]}&{urlencode(variables)}"
            yield response.follow(
                url_graphql_info,
                callback=self.page_subscribers_parse,
                cb_kwargs={
                    'pagename': pagename,
                    'page_id': page_id,
                    'variables': deepcopy(variables),
                    'type_info': type_info
                }
            )

        pages = j_data.get('data').get('user').get('edge_followed_by').get('edges')   # Список подписчиков/подписок
        for page in pages:                                                            # Перебираем сами подписки
            item = InstaparserItem(
                page_id=page['node']['id'],
                page_name=page['node']['username'],
                page_full_name=page['node']['full_name'],
                page_is_private=page['node']['is_private'],
                page_type=type_info,
                full_info=page['node'],

                page_main_id=page_id,
                page_main_name=pagename
            )
            yield item          # Передача в pipeline

    # Принимаем ответ на запрос на получение подписок
    # Параметр type - для унификации методов
    def page_subscriptions_parse(self, response: HtmlResponse, pagename, page_id, variables, type_info):
        j_data = json.loads(response.text)
        page_info = j_data.get('data').get('user').get('edge_follow').get('page_info')
        if page_info.get('has_next_page'):  # Если есть следующая страница
            variables['first'] = 12  # Новое значения количества получения новых данных
            variables['after'] = page_info['end_cursor']  # Новый параметр для получения следующих данных
            url_graphql_info = f"{self.graphql_url}query_hash={self.data_hashes[type_info]}&{urlencode(variables)}"
            yield response.follow(
                url_graphql_info,
                callback=self.page_subscriptions_parse,
                cb_kwargs={
                    'pagename': pagename,
                    'page_id': page_id,
                    'variables': deepcopy(variables),
                    'type_info': type_info
                }
            )
        # else:
        #    print()    # Проверял сколько считывается данных со страницы soul_box_spb после последнего запроса

        pages = j_data.get('data').get('user').get('edge_follow').get('edges')  # Список подписчиков/подписок
        for page in pages:  # Перебираем сами подписки
            item = InstaparserItem(
                page_id=page['node']['id'],
                page_name=page['node']['username'],
                page_full_name=page['node']['full_name'],
                page_is_private=page['node']['is_private'],
                page_type=type_info,
                full_info=page['node'],

                page_main_id=page_id,
                page_main_name=pagename
            )
            yield item  # Передача в pipeline
