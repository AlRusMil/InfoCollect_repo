# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class InstaparserItem(scrapy.Item):
    # Информация о подписчиках и подписках
    page_id = scrapy.Field()
    page_name = scrapy.Field()
    page_full_name = scrapy.Field()
    page_is_private = scrapy.Field()
    page_type = scrapy.Field()          # Тип страницы - подписчик или подписка
    full_info = scrapy.Field()

    # Информация об основной странице, на которой собирается информация
    page_main_id = scrapy.Field()
    page_main_name = scrapy.Field()

    _id = scrapy.Field()
    pass
