# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
from itemloaders import ItemLoader
from itemloaders.processors import TakeFirst


class LermerparserItem(scrapy.Item):
    article = scrapy.Field()
    # name: str = scrapy.Field(output_processor=TakeFirst())
    name = scrapy.Field()
    link = scrapy.Field()
    price = scrapy.Field()
    parameters = scrapy.Field()
    photos = scrapy.Field()

    _id = scrapy.Field()


class LerMerparserLoader(ItemLoader):
    default_output_processor = TakeFirst()

    def price_out(self, price):
        tmp = price[0].replace(' ', '')
        return float(tmp)

    def parameters_out(self, parameters: list):
        parameters_number = int(len(parameters) / 2)
        parameter_names = parameters[:parameters_number]
        parameters_values = parameters[parameters_number:]
        return {parameter_names[i]: parameters_values[i].replace('  ', '').replace('\n', '')
                for i in range(parameters_number)}

    def photos_out(self, photos: list):
        return photos