import scrapy

from scrapy.http import HtmlResponse
from lermerparser.items import LermerparserItem, LerMerparserLoader
# from itemloaders import ItemLoader

class LermerruSpider(scrapy.Spider):
    name = 'lermerru'
    allowed_domains = ['leroymerlin.ru']

    def __init__(self, search: str):
        super().__init__()
        self.start_urls = [f'https://leroymerlin.ru/search/?q={search}']

    def parse(self, response: HtmlResponse):
        next_page = response.xpath("//div[contains(@class, 'next-paginator-button-wrapper')]/a/@href").extract_first()
        products_links = response.xpath("//uc-product-list/product-card//a[@slot='name']")

        for link in products_links:
            yield response.follow(link, callback=self.product_parse)

        if next_page:
            yield response.follow(next_page, callback=self.parse)
        else:
            return

    def product_parse(self, response: HtmlResponse):
        # Ошибка: RuntimeError: To use XPath or CSS selectors, ItemLoader must be instantiated with a selector
        # loader = ItemLoader(item=LermerparserItem(), response=response)

        # Если не менять response на selector, то ошибка аналогична предыдущему случаю
        loader = LerMerparserLoader(item=LermerparserItem(), selector=response)

        loader.add_xpath('article', "//span[@slot='article']/@content")
        loader.add_xpath('name', "//h1/text()")
        loader.add_value('link', response.url)
        loader.add_xpath('price', "//quc-pdp-price-view[@slot='primary-price']/span[@slot='price']/text()")

        loader.add_xpath('parameters', "//dl[@class='def-list']/div[@class='def-list__group']/dt/text()")
        loader.add_xpath('parameters', "//dl[@class='def-list']/div[@class='def-list__group']/dd/text()")

        loader.add_xpath('photos', "//img[@slot='thumbs']/@src")

        yield loader.load_item()
